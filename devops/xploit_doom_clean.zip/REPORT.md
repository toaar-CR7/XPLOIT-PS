# DOOM Friendly Companion Bot

## Overview
Implemented a companion AI using existing DOOM enemy systems.

## What was broken
Game had no friendly entities. All actors were hostile.

## Fix
1. Spawned MT_TROOP near player in G_DoLoadLevel
2. Modified A_Look to force chase state for companion
3. Modified A_Chase to retarget hostile monsters
4. Disabled P_LookForPlayers targeting for companion
5. Prevented player damage triggering hostility in P_DamageMobj

## Why this works
DOOM uses state-driven AI via action pointers.  
By reusing existing chase and attack states, companion behaviour integrates naturally.

## Testing
- Companion spawns correctly
- Moves across level
- Attacks hostile monsters
- Does not attack player

## Limitations
Pathfinding inherits monster AI constraints in narrow geometry.
